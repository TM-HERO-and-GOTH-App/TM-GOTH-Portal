create view VW_ASSIGNMENT_LOG_bak as
select `T1`.`C_ID`         AS `C_ID`,
       `T9`.`C_TOKEN`      AS `C_TOKEN`,
       `T1`.`H_ID`         AS `H_ID`,
       `T1`.`H_ID_SUPPORT` AS `H_ID_SUPPORT`,
       `T1`.`SH_ID`        AS `SH_ID`,
       `T2`.`FULLNAME`     AS `ASSIGNED_BY`,
       `T2`.`EMAIL`        AS `EMAIL_ASSIGNED_BY`,
       `T4`.`L_NAME`       AS `GROUP_ASSIGNED_BY`,
       `T6`.`FULLNAME`     AS `ASSIGNED_TO`,
       `T6`.`EMAIL`        AS `EMAIL_ASSIGNED_TO`,
       `T8`.`L_NAME`       AS `GROUP_ASSIGNED_TO`,
       `T5`.`L_NAME`       AS `STAKEHOLDER_NAME`,
       `T1`.`AL_TYPE`      AS `LOG_TYPE`,
       `T1`.`LOGGED_DATE`  AS `LOGGED_DATE`
from ((((((((`emdev`.`TBL_ASSIGNMENT_LOG` `T1` join `emdev`.`TBL_HERO` `T2` on (`T1`.`H_ID` = `T2`.`H_ID`)) join `emdev`.`TBL_HERO_PROFILE` `T3` on (`T1`.`H_ID` = `T3`.`H_ID`)) join `emdev`.`TBL_CASE` `T9` on (`T1`.`C_ID` = `T9`.`C_ID`)) left join `emdev`.`TBL_LOV` `T4` on (`T3`.`SH_ID` = `T4`.`L_ID`)) left join `emdev`.`TBL_LOV` `T5` on (`T1`.`SH_ID` = `T5`.`L_ID`)) left join `emdev`.`TBL_HERO` `T6` on (`T1`.`H_ID_SUPPORT` = `T6`.`H_ID`)) left join `emdev`.`TBL_HERO_PROFILE` `T7` on (`T1`.`H_ID_SUPPORT` = `T7`.`H_ID`))
         left join `emdev`.`TBL_LOV` `T8` on (`T7`.`SH_ID` = `T4`.`L_ID`));

