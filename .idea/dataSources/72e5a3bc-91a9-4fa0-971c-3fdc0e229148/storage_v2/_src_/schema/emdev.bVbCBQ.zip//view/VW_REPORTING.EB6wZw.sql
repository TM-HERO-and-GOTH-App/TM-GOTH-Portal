create view VW_REPORTING as
select `A`.`CASE_NUM`                                                                                     AS `HERO_CASE_ID`,
       (select `E`.`CUSTOMER_NAME`
        from `emdev`.`TBL_CUSTOMER_PROFILE` `E`
        where `E`.`C_ID` = `A`.`C_ID`)                                                                    AS `CUST_NAME`,
       replace(replace(replace(`B`.`CASE_CONTENT`, '\r', ' '), '\n', ' '), ',',
               ' ')                                                                                       AS `DESCRIPTION`,
       (select `D`.`FULLNAME`
        from `emdev`.`TBL_HERO` `D`
        where `D`.`H_ID` = `A`.`H_ID`)                                                                    AS `HERO_LOGGER`,
       (select `C`.`L_NAME`
        from `emdev`.`TBL_LOV` `C`
        where `C`.`L_ID` = `B`.`AREA_LOCATION`)                                                           AS `AREA_LOCATION`,
       case
           when (select `C`.`L_NAME` from `emdev`.`TBL_LOV` `C` where `C`.`L_ID` = `B`.`CASE_STATUS`) = 'NEW'
               then 'UNASSIGNED'
           else (select `C`.`L_NAME`
                 from `emdev`.`TBL_LOV` `C`
                 where `C`.`L_ID` = `B`.`CASE_STATUS`) end                                                AS `CASE_STATUS`,
       (select `C`.`L_NAME`
        from `emdev`.`TBL_LOV` `C`
        where `C`.`L_ID` = `B`.`CASE_TYPE`)                                                               AS `CASE_TYPE`,
       case
           when (select `E`.`FLAG`
                 from (`emdev`.`TBL_HERO` `D`
                          join `emdev`.`TBL_STAFF` `E`)
                 where `D`.`H_ID` = `A`.`H_ID`
                   and convert(`D`.`EMAIL` using utf8) = `E`.`EMAIL`) = 'VIP' then 'VIP'
           else NULL end                                                                                  AS `VIP`,
       `B`.`PACKAGE_NAME`                                                                                 AS `PACKAGE_NAME`,
       (select `C`.`L_NAME` from `emdev`.`TBL_LOV` `C` where `C`.`L_ID` = `B`.`PRODUCT_NAME`)             AS `PRODUCT`,
       (select `C`.`L_NAME` from `emdev`.`TBL_LOV` `C` where `C`.`L_ID` = `B`.`SEGMENT_ID`)               AS `SEGMENT`,
       (select `D`.`FULLNAME`
        from `emdev`.`TBL_HERO` `D`
        where `D`.`H_ID` = `A`.`OWNER_ID`)                                                                AS `CASE_OWNER`,
       (select `F`.`L_NAME`
        from (`emdev`.`TBL_HERO_PROFILE` `HP`
                 join `emdev`.`TBL_LOV` `F`)
        where `HP`.`H_ID` = `A`.`OWNER_ID`
          and `HP`.`SH_ID` = `F`.`L_ID`)                                                                  AS `GROUP_`,
       `B`.`SR_NUM`                                                                                       AS `SR_NUM`,
       `B`.`TT_NUM`                                                                                       AS `TT_NUM`,
       case
           when `B`.`CASE_STATUS` = 70 then (select replace(replace(replace(`G`.`REMARK`, '\r', ' '), '\n', ' '), ',',
                                                            ' ')
                                             from `emdev`.`TBL_ACTION_REMARK` `G`
                                             where `G`.`C_ID` = `A`.`C_ID`
                                               and `G`.`REMARK_TYPE` = 'CLOSED'
                                             limit 1) end                                                 AS `UPDATE_REMARKS`,
       case
           when `B`.`CASE_STATUS` = 70 then (select `C`.`L_NAME`
                                             from (`emdev`.`TBL_ACTION_REMARK` `G`
                                                      join `emdev`.`TBL_LOV` `C`)
                                             where `G`.`C_ID` = `A`.`C_ID`
                                               and `G`.`CT_ID` = `C`.`L_ID`
                                               and `G`.`REMARK_TYPE` = 'CLOSED'
                                             limit 1) end                                                 AS `CLOSURE_TYPE`,
       `A`.`CREATED_DATE`                                                                                 AS `CREATED_DATE`,
       to_days(`A`.`CLOSED_DATE`) - to_days(`A`.`CREATED_DATE`)                                           AS `AGING_CLOSED`,
       (select `G`.`LOGGED_DATE`
        from `emdev`.`TBL_ACTION_REMARK` `G`
        where `G`.`C_ID` = `A`.`C_ID`
          and `G`.`REMARK_TYPE` = 'CLOSED'
        limit 1)                                                                                          AS `CLOSED_DATE`,
       to_days((select `G`.`LOGGED_DATE`
                from `emdev`.`TBL_ACTION_REMARK` `G`
                where `G`.`C_ID` = `A`.`C_ID`
                  and `G`.`REMARK_TYPE` = 'NEW'
                limit 1)) -
       to_days(`A`.`CREATED_DATE`)                                                                        AS `AGING_UNASSIGNED`,
       (select `G`.`LOGGED_DATE`
        from `emdev`.`TBL_ACTION_REMARK` `G`
        where `G`.`C_ID` = `A`.`C_ID`
          and `G`.`REMARK_TYPE` = 'NEW'
        limit 1)                                                                                          AS `DATE_UNASSIGNED`,
       to_days((select `G`.`LOGGED_DATE`
                from `emdev`.`TBL_ACTION_REMARK` `G`
                where `G`.`C_ID` = `A`.`C_ID`
                  and `G`.`REMARK_TYPE` = 'ASSIGNED'
                limit 1)) -
       to_days(`A`.`CREATED_DATE`)                                                                        AS `AGING_ASSIGNED`,
       (select `G`.`LOGGED_DATE`
        from `emdev`.`TBL_ACTION_REMARK` `G`
        where `G`.`C_ID` = `A`.`C_ID`
          and `G`.`REMARK_TYPE` = 'ASSIGNED'
        limit 1)                                                                                          AS `ASSIGNED_DATE`,
       to_days((select `G`.`LOGGED_DATE`
                from `emdev`.`TBL_ACTION_REMARK` `G`
                where `G`.`C_ID` = `A`.`C_ID`
                  and `G`.`REMARK_TYPE` = 'IN-PROGRESS'
                limit 1)) -
       to_days(`A`.`CREATED_DATE`)                                                                        AS `AGING_INPROGRESS`,
       (select `G`.`LOGGED_DATE`
        from `emdev`.`TBL_ACTION_REMARK` `G`
        where `G`.`C_ID` = `A`.`C_ID`
          and `G`.`REMARK_TYPE` = 'IN-PROGRESS'
        limit 1)                                                                                          AS `INPROGRESS_DATE`,
       to_days((select `G`.`LOGGED_DATE`
                from `emdev`.`TBL_ACTION_REMARK` `G`
                where `G`.`C_ID` = `A`.`C_ID`
                  and `G`.`REMARK_TYPE` = 'CANCELLED'
                limit 1)) -
       to_days(`A`.`CREATED_DATE`)                                                                        AS `AGING_CANCELLED`,
       (select `G`.`LOGGED_DATE`
        from `emdev`.`TBL_ACTION_REMARK` `G`
        where `G`.`C_ID` = `A`.`C_ID`
          and `G`.`REMARK_TYPE` = 'CANCELLED'
        limit 1)                                                                                          AS `CANCELLED_DATE`
from (`emdev`.`TBL_CASE` `A`
         join `emdev`.`TBL_CASE_DETAIL` `B` on (`A`.`C_ID` = `B`.`C_ID`));

