create definer = root@`%` trigger create_new_user
    before insert
    on TBL_HERO
    for each row
BEGIN
	SET NEW.H_TOKEN = MD5(CURRENT_TIMESTAMP);
END;

