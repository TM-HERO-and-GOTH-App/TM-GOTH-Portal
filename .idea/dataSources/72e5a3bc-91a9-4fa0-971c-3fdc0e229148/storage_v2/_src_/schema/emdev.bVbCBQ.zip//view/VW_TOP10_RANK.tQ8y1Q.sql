create view VW_TOP10_RANK as
select `T1`.`FULLNAME` AS `FULLNAME`,
       `T2`.`SCORE`    AS `SCORE`,
       `T2`.`LEVEL`    AS `LEVEL`,
       `T2`.`NICKNAME` AS `NICKNAME`,
       `T3`.`PICTURE`  AS `AVATAR_PICTURE`
from ((`emdev`.`TBL_HERO` `T1` join `emdev`.`TBL_HERO_PROFILE` `T2` on (`T1`.`H_ID` = `T2`.`H_ID`))
         left join `emdev`.`TBL_BLOB` `T3` on (`T2`.`B_ID` = `T3`.`B_ID`))
where `T1`.`ACTIVATION_STATUS` = 'Y'
order by `T2`.`SCORE` desc
limit 10;

