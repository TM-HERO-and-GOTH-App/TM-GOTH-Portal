create definer = root@`%` trigger create_new_case
    before insert
    on TBL_CASE
    for each row
BEGIN
	SET NEW.C_TOKEN = MD5(CURRENT_TIMESTAMP);
END;

