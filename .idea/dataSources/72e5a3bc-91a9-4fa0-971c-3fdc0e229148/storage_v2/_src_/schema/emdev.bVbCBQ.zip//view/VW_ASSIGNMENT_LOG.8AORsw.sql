create view VW_ASSIGNMENT_LOG as
select `T2`.`CASE_NUM`     AS `CASE_NUM`,
       `T2`.`CREATED_DATE` AS `CREATED_DATE`,
       `T4`.`FULLNAME`     AS `ASSIGNED_BY`,
       `T4`.`EMAIL`        AS `EMAIL_ASSIGNED_BY`,
       `T9`.`L_NAME`       AS `GROUP_ASSIGNED_BY`,
       `T6`.`FULLNAME`     AS `ASSIGNED_TO`,
       `T6`.`EMAIL`        AS `EMAIL_ASSIGNED_TO`,
       `T8`.`L_NAME`       AS `GROUP_ASSIGNED_TO`,
       `T1`.`AL_TYPE`      AS `LOG_TYPE`,
       `T1`.`LOGGED_DATE`  AS `LOGGED_DATE`,
       `T3`.`L_NAME`       AS `STAKEHOLER_NAME`,
       `T1`.`C_ID`         AS `C_ID`,
       `T2`.`C_TOKEN`      AS `C_TOKEN`,
       `T1`.`H_ID`         AS `H_ID`,
       `T1`.`H_ID_SUPPORT` AS `H_ID_SUPPORT`,
       `T1`.`SH_ID`        AS `SH_ID`
from ((((((((`emdev`.`TBL_ASSIGNMENT_LOG` `T1` join `emdev`.`TBL_CASE` `T2` on (`T1`.`C_ID` = `T2`.`C_ID`)) join `emdev`.`TBL_LOV` `T3` on (`T1`.`SH_ID` = `T3`.`L_ID`)) join `emdev`.`TBL_HERO` `T4` on (`T1`.`H_ID` = `T4`.`H_ID`)) join `emdev`.`TBL_HERO_PROFILE` `T5` on (`T5`.`H_ID` = `T4`.`H_ID`)) join `emdev`.`TBL_LOV` `T9` on (`T5`.`SH_ID` = `T9`.`L_ID`)) left join `emdev`.`TBL_HERO` `T6` on (`T1`.`H_ID_SUPPORT` = `T6`.`H_ID`)) left join `emdev`.`TBL_HERO_PROFILE` `T7` on (`T7`.`H_ID` = `T6`.`H_ID`))
         left join `emdev`.`TBL_LOV` `T8` on (`T7`.`SH_ID` = `T8`.`L_ID`));

