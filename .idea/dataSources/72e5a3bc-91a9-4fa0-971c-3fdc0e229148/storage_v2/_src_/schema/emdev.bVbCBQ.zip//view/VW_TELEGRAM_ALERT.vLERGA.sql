create view VW_TELEGRAM_ALERT as
select `T1`.`C_ID`        AS `C_ID`,
       `T1`.`GCHAT`       AS `GCHAT`,
       `T1`.`MESSAGE`     AS `MESSAGE`,
       `T1`.`LOGGED_DATE` AS `LOGGED_DATE`,
       `T2`.`C_TOKEN`     AS `C_TOKEN`,
       `T3`.`SH_ID`       AS `SH_ID`,
       `T4`.`L_NAME`      AS `CASE_STATUS`
from (((`emdev`.`TBL_TELEGRAM_ALERT` `T1` join `emdev`.`TBL_CASE` `T2` on (`T1`.`C_ID` = `T2`.`C_ID`)) join `emdev`.`TBL_CASE_DETAIL` `T3` on (`T2`.`C_ID` = `T3`.`C_ID`))
         left join `emdev`.`TBL_LOV` `T4` on (`T3`.`CASE_STATUS` = `T4`.`L_ID`));

-- comment on column VW_TELEGRAM_ALERT.GCHAT not supported: VIP/SALES/BANJIR/etc

-- comment on column VW_TELEGRAM_ALERT.SH_ID not supported: STAKEHOLDER_ID = L_ID IN TBL_LOV

