create definer = root@`%` trigger backup_tbl_case_detail
    before delete
    on TBL_CASE_DETAIL
    for each row
BEGIN

   
   INSERT INTO BAK_CASE_DETAIL
   ( CD_ID,
	 C_ID,
     SH_ID,
     CASE_TYPE,
     PRODUCT_NAME,
     RATING,
     RATING_REMARK,
     CASE_CONTENT,
     CASE_STATUS,
     PACKAGE_NAME,
     SERVICE_ID,
     SERVICE_ADDRESS,
     SR_NUM,
     TT_NUM,
     AREA_LOCATION,
     SEGMENT_ID,
     FLAG,
     SOURCE_ID,
     DELETED_BY)
   VALUES
   ( OLD.CD_ID,
	 OLD.C_ID,
     OLD.SH_ID,
     OLD.CASE_TYPE,
     OLD.PRODUCT_NAME,
     OLD.RATING,
     OLD.RATING_REMARK,
     OLD.CASE_CONTENT,
     OLD.CASE_STATUS,
     OLD.PACKAGE_NAME,
     OLD.SERVICE_ID,
     OLD.SERVICE_ADDRESS,
     OLD.SR_NUM,
     OLD.TT_NUM,
     OLD.AREA_LOCATION,
     OLD.SEGMENT_ID,
     OLD.FLAG,
     OLD.SOURCE_ID,
     USER());

END;

