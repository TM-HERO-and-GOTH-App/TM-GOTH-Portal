create view VW_STAKEHOLDER_USERS as
select `T1`.`H_TOKEN`           AS `H_TOKEN`,
       `T1`.`FULLNAME`          AS `FULLNAME`,
       `T1`.`ACTIVATION_STATUS` AS `ACTIVATION_STATUS`,
       `T2`.`NICKNAME`          AS `NICKNAME`,
       `T3`.`L_NAME`            AS `STAKEHOLDER_NAME`
from ((`emdev`.`TBL_HERO` `T1` join `emdev`.`TBL_HERO_PROFILE` `T2` on (`T2`.`H_ID` = `T1`.`H_ID` and `T2`.`CATEGORY` = 'STAKEHOLDER'))
         join `emdev`.`TBL_LOV` `T3` on (`T3`.`L_ID` = `T2`.`SH_ID`));

