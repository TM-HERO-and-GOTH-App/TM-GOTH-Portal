create definer = root@`%` trigger backup_tbl_case
    before delete
    on TBL_CASE
    for each row
BEGIN

   
   INSERT INTO BAK_CASE
   ( C_ID,
     H_ID,
     CASE_NUM,
     CREATED_DATE,
     CLOSED_DATE,
     OWNER_ID,
     OWNER_ID_SUPPORT,
     C_TOKEN,
     DELETED_BY)
   VALUES
   ( OLD.C_ID,
     OLD.H_ID,
     OLD.CASE_NUM,
     OLD.CREATED_DATE,
     OLD.CLOSED_DATE,
     OLD.OWNER_ID,
     OLD.OWNER_ID_SUPPORT,
     OLD.C_TOKEN,
     USER());

END;

