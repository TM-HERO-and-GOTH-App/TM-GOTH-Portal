create definer = root@`%` trigger insert_notification_log
    after insert
    on TBL_NOTIFICATION
    for each row
BEGIN
   CALL Insert_Notification_Log(NEW.`C_ID`);
END;

