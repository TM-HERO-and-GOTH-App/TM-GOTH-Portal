create view VW_GCHAT_MEMBERS as
select `T1`.`C_ID`     AS `C_ID`,
       `T2`.`H_ID`     AS `H_ID`,
       `T2`.`FULLNAME` AS `FULLNAME`,
       `T3`.`NICKNAME` AS `NICKNAME`,
       `T3`.`CATEGORY` AS `CATEGORY`,
       `T4`.`C_TOKEN`  AS `C_TOKEN`,
       `T2`.`H_TOKEN`  AS `H_TOKEN`,
       `T5`.`L_NAME`   AS `STAKEHOLDER_NAME`
from ((((`emdev`.`TBL_GROUP_CHAT` `T1` join `emdev`.`TBL_HERO` `T2` on (`T1`.`H_ID` = `T2`.`H_ID`)) join `emdev`.`TBL_HERO_PROFILE` `T3` on (`T2`.`H_ID` = `T3`.`H_ID`)) join `emdev`.`TBL_CASE` `T4` on (`T1`.`C_ID` = `T4`.`C_ID`))
         left join `emdev`.`TBL_LOV` `T5` on (`T3`.`SH_ID` = `T5`.`L_ID`));

