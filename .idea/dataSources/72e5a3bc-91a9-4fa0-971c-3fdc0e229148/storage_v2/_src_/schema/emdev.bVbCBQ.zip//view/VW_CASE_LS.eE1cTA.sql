create view VW_CASE_LS as
select `T1`.`C_ID`                                                                                          AS `C_ID`,
       `T1`.`C_TOKEN`                                                                                       AS `C_TOKEN`,
       `T1`.`H_ID`                                                                                          AS `H_ID`,
       `T7`.`H_TOKEN`                                                                                       AS `H_TOKEN`,
       `T1`.`CASE_NUM`                                                                                      AS `CASE_NUM`,
       `T1`.`CREATED_DATE`                                                                                  AS `CREATED_DATE`,
       `T1`.`CLOSED_DATE`                                                                                   AS `CLOSED_DATE`,
       `T1`.`OWNER_ID`                                                                                      AS `O_ID`,
       `T16`.`FULLNAME`                                                                                     AS `OWNER_NAME`,
       `T1`.`OWNER_ID_SUPPORT`                                                                              AS `S_ID`,
       `GET_AGING_WEEKDAYS`(`T1`.`CREATED_DATE`, current_timestamp())                                       AS `UNCLOSED_AGING`,
       `GET_AGING_WEEKDAYS`(`T1`.`CREATED_DATE`, `T1`.`CLOSED_DATE`)                                        AS `CLOSED_AGING`,
       `GET_AGING`(`T1`.`CREATED_DATE`, current_timestamp())                                                AS `UNCLOSED_AGING_DH`,
       `GET_AGING`(`T1`.`CREATED_DATE`, `T1`.`CLOSED_DATE`)                                                 AS `CLOSED_AGING_DH`,
       `T2`.`SH_ID`                                                                                         AS `SH_ID`,
       `T10`.`L_NAME`                                                                                       AS `CASE_TYPE`,
       `T11`.`L_NAME`                                                                                       AS `PRODUCT_NAME`,
       `T2`.`CASE_CONTENT`                                                                                  AS `CASE_CONTENT`,
       `T2`.`AREA_LOCATION`                                                                                 AS `AREA_LOCATION_ID`,
       `T13`.`L_NAME`                                                                                       AS `AREA_LOCATION`,
       `T12`.`L_NAME`                                                                                       AS `CASE_STATUS`,
       `T2`.`RATING`                                                                                        AS `RATING`,
       `T2`.`RATING_REMARK`                                                                                 AS `RATING_REMARK`,
       `T2`.`PACKAGE_NAME`                                                                                  AS `PACKAGE_NAME`,
       `T2`.`SERVICE_ADDRESS`                                                                               AS `SERVICE_ADDRESS`,
       `T2`.`SR_NUM`                                                                                        AS `SR_NUM`,
       `T2`.`TT_NUM`                                                                                        AS `TT_NUM`,
       `T3`.`CUSTOMER_NAME`                                                                                 AS `CUSTOMER_NAME`,
       `T3`.`ACTUAL_CUSTOMER_NAME`                                                                          AS `ACTUAL_CUSTOMER_NAME`,
       `T3`.`NRIC_NUM`                                                                                      AS `NRIC_NUM`,
       `T3`.`MOBILE_NUM`                                                                                    AS `MOBILE_NUM`,
       `T4`.`REMARK_TYPE`                                                                                   AS `REMARK_TYPE`,
       `T4`.`REMARK`                                                                                        AS `REMARK`,
       `T6`.`L_NAME`                                                                                        AS `CLOSURE_TYPE`,
       `T7`.`EMAIL`                                                                                         AS `EMAIL`,
       `T7`.`FULLNAME`                                                                                      AS `FULLNAME`,
       `T8`.`LONGITUDE`                                                                                     AS `LONGITUDE`,
       `T8`.`LATITUDE`                                                                                      AS `LATITUDE`,
       `T8`.`B_ID`                                                                                          AS `B_ID`,
       `T9`.`L_NAME`                                                                                        AS `STAKEHOLDER_NAME`,
       `T2`.`CASE_TYPE`                                                                                     AS `CASE_TYPE_ID`,
       `T2`.`PRODUCT_NAME`                                                                                  AS `PRODUCT_NAME_ID`,
       `T2`.`CASE_STATUS`                                                                                   AS `CASE_STATUS_ID`,
       `T4`.`CT_ID`                                                                                         AS `CT_ID`,
       'null'                                                                                               AS `PICTURE`,
       `T2`.`SERVICE_ID`                                                                                    AS `SERVICE_ID`,
       case when `T22`.`MANAGER_LVL` = 'S' or `T22`.`MANAGER_LVL` = 'T' then `T22`.`FULLNAME` else NULL end AS `VIP`,
       `T14`.`STAFF_ID`                                                                                     AS `STAFF_ID`,
       `T14`.`PERSONNEL_NO`                                                                                 AS `PERNO`,
       `T2`.`SEGMENT_ID`                                                                                    AS `SEGMENT_ID`,
       `T17`.`L_NAME`                                                                                       AS `SEGMENT_NAME`,
       case when `T2`.`FLAG` = 'PROTECT' then 'COMPLAINT' else `T2`.`FLAG` end                              AS `FLAG`,
       `T2`.`SOURCE_ID`                                                                                     AS `SOURCE_ID`,
       `T18`.`L_NAME`                                                                                       AS `SOURCE_NAME`,
       `T2`.`SUB_SOURCE_ID`                                                                                 AS `SUB_SOURCE_ID`,
       `T19`.`L_NAME`                                                                                       AS `SUB_SOURCE_NAME`,
       case when `T2`.`SMS_DESC` = 'TqUnifi' then 'Yes' else 'No' end                                       AS `SMS_DESC`,
       `T2`.`ELIGIBILITY`                                                                                   AS `ELIGIBILITY`,
       `T20`.`TMCC_NAME`                                                                                    AS `TMCC_NAME`,
       `T20`.`TMCC_IDM`                                                                                     AS `TMCC_IDM`,
       `T20`.`TMCC_EMAIL`                                                                                   AS `TMCC_EMAIL`,
       `T20`.`TMCC_PERNO`                                                                                   AS `TMCC_PERNO`,
       `T20`.`TMCC_ACTIVE`                                                                                  AS `TMCC_ACTIVE`,
       `T20`.`TMCC_ELIGIBLE`                                                                                AS `TMCC_ELIGIBLE`,
       `T2`.`CKC`                                                                                           AS `CKC`,
       `T2`.`CKC_NUM`                                                                                       AS `CKC_NUM`,
       `T2`.`LOGIN_ID`                                                                                      AS `LOGIN_ID`,
       `T21`.`CONTENT`                                                                                      AS `HEROBUDDY_CONTENT`,
       `T2`.`STAKEHOLDER_REF`                                                                               AS `STAKEHOLDER_REF`,
       `T2`.`EXT_SYS_REF`                                                                                   AS `EXT_SYS_REF`,
       `T2`.`SEGMENT_CODE`                                                                                  AS `SEGMENT_CODE`
from (((((((((((((((((((`emdev`.`TBL_CASE` `T1` join `emdev`.`TBL_CASE_DETAIL` `T2` on (`T1`.`C_ID` = `T2`.`C_ID`)) join `emdev`.`TBL_HERO` `T7` on (`T1`.`H_ID` = `T7`.`H_ID`)) left join `emdev`.`TBL_CUSTOMER_PROFILE` `T3` on (`T1`.`C_ID` = `T3`.`C_ID`)) left join `emdev`.`TBL_ACTION_REMARK` `T4` on (
            `T1`.`C_ID` = `T4`.`C_ID` and `T4`.`AR_ID` = (select `T5`.`AR_ID`
                                                          from `emdev`.`TBL_ACTION_REMARK` `T5`
                                                          where `T1`.`C_ID` = `T5`.`C_ID`
                                                          order by `T5`.`LOGGED_DATE` desc
                                                          limit 1))) left join `emdev`.`TBL_PICTURE` `T8` on (`T1`.`C_ID` = `T8`.`C_ID`)) left join `emdev`.`TBL_LOV` `T6` on (`T4`.`CT_ID` = `T6`.`L_ID`)) left join `emdev`.`TBL_LOV` `T9` on (`T2`.`SH_ID` = `T9`.`L_ID`)) left join `emdev`.`TBL_LOV` `T10` on (`T2`.`CASE_TYPE` = `T10`.`L_ID`)) left join `emdev`.`TBL_LOV` `T11` on (`T2`.`PRODUCT_NAME` = `T11`.`L_ID`)) left join `emdev`.`TBL_LOV` `T12` on (`T2`.`CASE_STATUS` = `T12`.`L_ID`)) left join `emdev`.`TBL_LOV` `T13` on (`T2`.`AREA_LOCATION` = `T13`.`L_ID`)) left join `emdev`.`TBL_STAFF` `T14` on (convert(`T7`.`EMAIL` using utf8) = `T14`.`EMAIL`)) left join `emdev`.`TBL_LDAP_PROFILE` `T22` on (convert(`T7`.`EMAIL` using utf8) = convert(`T22`.`EMAIL` using utf8))) left join `emdev`.`TBL_HERO` `T16` on (`T1`.`OWNER_ID` = `T16`.`H_ID`)) left join `emdev`.`TBL_LOV` `T17` on (`T2`.`SEGMENT_ID` = `T17`.`L_ID`)) left join `emdev`.`TBL_LOV` `T18` on (`T2`.`SOURCE_ID` = `T18`.`L_ID`)) left join `emdev`.`TBL_LOV` `T19` on (`T2`.`SUB_SOURCE_ID` = `T19`.`L_ID`)) left join `emdev`.`TBL_TMCC_STAFF` `T20` on (
        convert(`T7`.`EMAIL` using utf8) = convert(`T20`.`TMCC_EMAIL` using utf8)))
         left join `emdev`.`TBL_HEROBUDDY_INFO` `T21` on (`T1`.`C_ID` = `T21`.`C_ID`));

-- comment on column VW_CASE_LS.H_ID not supported: USER WHO LOGGED THE CASE

-- comment on column VW_CASE_LS.CASE_NUM not supported: 12D = H-1710170012

-- comment on column VW_CASE_LS.O_ID not supported: AGENT H_ID WHO RESPONSIBLE TO THE CASE

-- comment on column VW_CASE_LS.S_ID not supported: REQ SUPPORT : Support person is when there is specific personnel identified from the stakeholder’s team

-- comment on column VW_CASE_LS.SH_ID not supported: STAKEHOLDER_ID = L_ID IN TBL_LOV

-- comment on column VW_CASE_LS.CASE_CONTENT not supported: DETAIL OF CASE/COMPLAINT

-- comment on column VW_CASE_LS.AREA_LOCATION_ID not supported: REFER TO TBL_LOV

-- comment on column VW_CASE_LS.RATING not supported: FROM 1 - 10

-- comment on column VW_CASE_LS.NRIC_NUM not supported: NRIC/PASSPORT-NUM/

-- comment on column VW_CASE_LS.REMARK_TYPE not supported: NEW/ASSIGNED/IN-PROGRESS/CLOSED

-- comment on column VW_CASE_LS.EMAIL not supported: AS USERNAME FOR LOGIN

-- comment on column VW_CASE_LS.CASE_TYPE_ID not supported: A.K.A AREA; FULFILLMENT/ASSURANCE/BILLING/etc; REFER TO L_ID IN TBL_LOV

-- comment on column VW_CASE_LS.PRODUCT_NAME_ID not supported: FIXED/MOBILE/etc ; REFER TO L_ID IN TBL_LOV

-- comment on column VW_CASE_LS.CASE_STATUS_ID not supported: REFER TO L_ID IN TBL_LOV : NEW/ACKNOWLEDGE/IN-PROGRESS/CLOSED

-- comment on column VW_CASE_LS.CT_ID not supported: CLOSURE_TYPE; REFER TO L_ID FROM TBL_LOV

-- comment on column VW_CASE_LS.SEGMENT_ID not supported: REFER TO TBL_LOV (Consumer/SME/Enterprise/Government) 

-- comment on column VW_CASE_LS.SOURCE_ID not supported: REFER TO TBL_LOV

-- comment on column VW_CASE_LS.SUB_SOURCE_ID not supported: REFER TO TBL_LOV

-- comment on column VW_CASE_LS.ELIGIBILITY not supported: LOGGER'S ELIGIBILITY STATUS UPON CASE CREATION

-- comment on column VW_CASE_LS.HEROBUDDY_CONTENT not supported: IN JSON FORMAT

-- comment on column VW_CASE_LS.STAKEHOLDER_REF not supported: RRT,NMO,CSM,NOC

