create view VW_CHAT_MESSAGES as
select `T1`.`MB_ID`            AS `MB_ID`,
       `T1`.`C_ID`             AS `C_ID`,
       `T1`.`H_ID`             AS `H_ID`,
       `T1`.`FLAG`             AS `FLAG`,
       `T1`.`MESSAGE`          AS `MESSAGE`,
       `T1`.`POSTED_DATE`      AS `POSTED_DATE`,
       `T2`.`C_TOKEN`          AS `C_TOKEN`,
       `T2`.`OWNER_ID`         AS `O_ID`,
       `T2`.`OWNER_ID_SUPPORT` AS `S_ID`,
       `T3`.`FULLNAME`         AS `FULLNAME`,
       `T4`.`PICTURE`          AS `FILENAME`,
       `T1`.`B_ID`             AS `B_ID`
from (((`emdev`.`TBL_MESSAGE_BOX` `T1` join `emdev`.`TBL_CASE` `T2` on (`T1`.`C_ID` = `T2`.`C_ID`)) join `emdev`.`TBL_HERO` `T3` on (`T1`.`H_ID` = `T3`.`H_ID`))
         left join `emdev`.`TBL_BLOB` `T4` on (`T1`.`B_ID` = `T4`.`B_ID`))
order by `T1`.`POSTED_DATE` desc;

-- comment on column VW_CHAT_MESSAGES.C_ID not supported: REFER TO TBL_CASE_INFO

-- comment on column VW_CHAT_MESSAGES.H_ID not supported: REFER TO TBL_HERO_PROFILE

-- comment on column VW_CHAT_MESSAGES.FLAG not supported: FE/BE

-- comment on column VW_CHAT_MESSAGES.O_ID not supported: AGENT H_ID WHO RESPONSIBLE TO THE CASE

-- comment on column VW_CHAT_MESSAGES.S_ID not supported: REQ SUPPORT : Support person is when there is specific personnel identified from the stakeholder’s team

-- comment on column VW_CHAT_MESSAGES.B_ID not supported: REFER TO TBL_BLOB

