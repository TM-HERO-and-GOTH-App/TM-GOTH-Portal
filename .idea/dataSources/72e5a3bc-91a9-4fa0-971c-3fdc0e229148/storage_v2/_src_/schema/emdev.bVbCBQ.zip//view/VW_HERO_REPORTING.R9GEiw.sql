create view VW_HERO_REPORTING as
select `A`.`CASE_NUM`                                                                                                 AS `HERO_CASE_ID`,
       replace(replace(replace((select `E`.`CUSTOMER_NAME`
                                from `emdev`.`TBL_CUSTOMER_PROFILE` `E`
                                where `E`.`C_ID` = `A`.`C_ID`), '\r', ' '), '\n                ', ' '), ',',
               ' ')                                                                                                   AS `CUST_NAME`,
       replace(replace(replace(replace(replace(replace(`B`.`CASE_CONTENT`, '\r', ' '), '\n                            ',
                                               ' '), ',', ' '), ';', ' '), '<', ' '), '"',
               ' ')                                                                                                   AS `DESCRIPTION`,
       (select `D`.`FULLNAME`
        from `emdev`.`TBL_HERO` `D`
        where `D`.`H_ID` = `A`.`H_ID`)                                                                                AS `HERO_LOGGER`,
       (select `ST`.`STATE`
        from (`emdev`.`TBL_STAFF` `ST`
                 join `emdev`.`TBL_HERO` `HERO`)
        where `HERO`.`H_ID` = `A`.`H_ID`
          and convert(`HERO`.`EMAIL` using utf8) = `ST`.`EMAIL`)                                                      AS `HERO_STATE`,
       (select `C`.`L_NAME`
        from `emdev`.`TBL_LOV` `C`
        where `C`.`L_ID` = `B`.`AREA_LOCATION`)                                                                       AS `AREA_LOCATION`,
       case
           when (select `C`.`L_NAME` from `emdev`.`TBL_LOV` `C` where `C`.`L_ID` = `B`.`CASE_STATUS`) = 'NEW'
               then 'UNASSIGNED'
           else (select `C`.`L_NAME`
                 from `emdev`.`TBL_LOV` `C`
                 where `C`.`L_ID` = `B`.`CASE_STATUS`) end                                                            AS `CASE_STATUS`,
       (select `C`.`L_NAME`
        from `emdev`.`TBL_LOV` `C`
        where `C`.`L_ID` = `B`.`CASE_TYPE`)                                                                           AS `CASE_TYPE`,
       case
           when (select `E`.`FLAG`
                 from (`emdev`.`TBL_HERO` `D`
                          join `emdev`.`TBL_STAFF` `E`)
                 where `D`.`H_ID` = `A`.`H_ID`
                   and convert(`D`.`EMAIL` using utf8) = `E`.`EMAIL`) = 'VIP' then 'VIP'
           else NULL end                                                                                              AS `VIP`,
       replace(replace(`B`.`PACKAGE_NAME`, ';', ' '), ',', ' ')                                                       AS `PACKAGE_NAME`,
       (select `C`.`L_NAME`
        from `emdev`.`TBL_LOV` `C`
        where `C`.`L_ID` = `B`.`PRODUCT_NAME`)                                                                        AS `PRODUCT`,
       (select `C`.`L_NAME`
        from `emdev`.`TBL_LOV` `C`
        where `C`.`L_ID` = `B`.`SEGMENT_ID`)                                                                          AS `SEGMENT`,
       (select `D`.`FULLNAME`
        from `emdev`.`TBL_HERO` `D`
        where `D`.`H_ID` = `A`.`OWNER_ID`)                                                                            AS `CASE_OWNER`,
       (select `C`.`L_NAME`
        from `emdev`.`TBL_LOV` `C`
        where `C`.`L_ID` = `B`.`SH_ID`)                                                                               AS `GROUP_`,
       replace(replace(replace(replace(`B`.`SR_NUM`, '\r', ' '), '\n                    ', ' '), ';', ' '), ',',
               ' ')                                                                                                   AS `SR_NUM`,
       replace(replace(replace(replace(`B`.`TT_NUM`, '\r', ' '), '\n                    ', ' '), ';', ' '), ',',
               ' ')                                                                                                   AS `TT_NUM`,
       case
           when `B`.`CASE_STATUS` = 70 then (select replace(replace(replace(replace(replace(`G`.`REMARK`, '\r', ' '),
                                                                                    '\n                                            ',
                                                                                    ' '), ',', ' '), ';', ' '), '<',
                                                            ' ')
                                             from `emdev`.`TBL_ACTION_REMARK` `G`
                                             where `G`.`C_ID` = `A`.`C_ID`
                                               and `G`.`REMARK_TYPE` = 'CLOSED'
                                             limit 1) end                                                             AS `UPDATE_REMARKS`,
       case
           when `B`.`CASE_STATUS` = 70 then (select `C`.`L_NAME`
                                             from (`emdev`.`TBL_ACTION_REMARK` `G`
                                                      join `emdev`.`TBL_LOV` `C`)
                                             where `G`.`C_ID` = `A`.`C_ID`
                                               and `G`.`CT_ID` = `C`.`L_ID`
                                               and `G`.`REMARK_TYPE` = 'CLOSED'
                                             limit 1) end                                                             AS `CLOSURE_TYPE`,
       `A`.`CREATED_DATE`                                                                                             AS `CREATED_DATE`,
       date_format(`A`.`CREATED_DATE`, '%M %Y')                                                                       AS `MONTH_YEAR`,
       case
           when `B`.`CASE_STATUS` = 70 then case
                                                when (select count(0)
                                                      from `emdev`.`TBL_ACTION_REMARK` `G`
                                                      where `G`.`C_ID` = `A`.`C_ID`
                                                        and `G`.`REMARK_TYPE` = 'IN-PROGRESS'
                                                      limit 1) > 0 then to_days(`A`.`CLOSED_DATE`) -
                                                                        to_days((select `G`.`LOGGED_DATE`
                                                                                 from `emdev`.`TBL_ACTION_REMARK` `G`
                                                                                 where `G`.`C_ID` = `A`.`C_ID`
                                                                                   and `G`.`REMARK_TYPE` = 'IN-PROGRESS'
                                                                                 limit 1))
                                                else case
                                                         when (select count(0)
                                                               from `emdev`.`TBL_ASSIGNMENT_LOG` `H`
                                                               where `H`.`C_ID` = `A`.`C_ID`
                                                                 and `H`.`AL_TYPE` = 'SUPPORT'
                                                               limit 1) > 0 then to_days(`A`.`CLOSED_DATE`) -
                                                                                 to_days((select `H`.`LOGGED_DATE`
                                                                                          from `emdev`.`TBL_ASSIGNMENT_LOG` `H`
                                                                                          where `H`.`C_ID` = `A`.`C_ID`
                                                                                            and `H`.`AL_TYPE` = 'SUPPORT'
                                                                                          limit 1))
                                                         else to_days(`A`.`CLOSED_DATE`) -
                                                              to_days((select `H`.`LOGGED_DATE`
                                                                       from `emdev`.`TBL_ASSIGNMENT_LOG` `H`
                                                                       where `H`.`C_ID` = `A`.`C_ID`
                                                                         and `H`.`AL_TYPE` = 'SELF'
                                                                       limit 1)) end end end                          AS `AGING_CLOSED`,
       case
           when `B`.`CASE_STATUS` = 70 then (select `G`.`LOGGED_DATE`
                                             from `emdev`.`TBL_ACTION_REMARK` `G`
                                             where `G`.`C_ID` = `A`.`C_ID`
                                               and `G`.`REMARK_TYPE` = 'CLOSED'
                                             limit 1) end                                                             AS `CLOSED_DATE`,
       to_days((select min(`H`.`LOGGED_DATE`)
                from `emdev`.`TBL_ASSIGNMENT_LOG` `H`
                where `H`.`C_ID` = `A`.`C_ID`
                limit 1)) -
       to_days(`A`.`CREATED_DATE`)                                                                                    AS `AGING_UNASSIGNED`,
       (select min(`H`.`LOGGED_DATE`)
        from `emdev`.`TBL_ASSIGNMENT_LOG` `H`
        where `H`.`C_ID` = `A`.`C_ID`
        limit 1)                                                                                                      AS `DATE_UNASSIGNED`,
       case
           when (select count(0)
                 from `emdev`.`TBL_ASSIGNMENT_LOG` `H`
                 where `H`.`C_ID` = `A`.`C_ID`
                   and `H`.`AL_TYPE` = 'TRANSFER'
                 limit 1) > 0 then case
                                       when (select count(0)
                                             from `emdev`.`TBL_ASSIGNMENT_LOG` `H`
                                             where `H`.`C_ID` = `A`.`C_ID` and `H`.`AL_TYPE` = 'SELF'
                                             limit 1) > 0 then to_days((select min(`H`.`LOGGED_DATE`)
                                                                        from `emdev`.`TBL_ASSIGNMENT_LOG` `H`
                                                                        where `H`.`C_ID` = `A`.`C_ID`
                                                                          and `H`.`AL_TYPE` = 'SELF'
                                                                        limit 1)) -
                                                               to_days((select min(`H`.`LOGGED_DATE`)
                                                                        from `emdev`.`TBL_ASSIGNMENT_LOG` `H`
                                                                        where `H`.`C_ID` = `A`.`C_ID`
                                                                        limit 1))
                                       else to_days((select min(`H`.`LOGGED_DATE`)
                                                     from `emdev`.`TBL_ASSIGNMENT_LOG` `H`
                                                     where `H`.`C_ID` = `A`.`C_ID`
                                                       and `H`.`AL_TYPE` = 'SUPPORT'
                                                     limit 1)) - to_days((select min(`H`.`LOGGED_DATE`)
                                                                          from `emdev`.`TBL_ASSIGNMENT_LOG` `H`
                                                                          where `H`.`C_ID` = `A`.`C_ID`
                                                                            and `H`.`AL_TYPE` = 'TRANSFER'
                                                                          limit 1)) end
           else case
                    when (select count(0)
                          from `emdev`.`TBL_ASSIGNMENT_LOG` `H`
                          where `H`.`C_ID` = `A`.`C_ID`
                            and `H`.`AL_TYPE` = 'SUPPORT'
                          limit 1) > 0 then to_days((select min(`H`.`LOGGED_DATE`)
                                                     from `emdev`.`TBL_ASSIGNMENT_LOG` `H`
                                                     where `H`.`C_ID` = `A`.`C_ID`
                                                       and `H`.`AL_TYPE` = 'SELF'
                                                     limit 1)) - to_days(`A`.`CREATED_DATE`)
                    else to_days((select min(`H`.`LOGGED_DATE`)
                                  from `emdev`.`TBL_ASSIGNMENT_LOG` `H`
                                  where `H`.`C_ID` = `A`.`C_ID`
                                    and `H`.`AL_TYPE` = 'SUPPORT'
                                  limit 1)) -
                         to_days(`A`.`CREATED_DATE`) end end                                                          AS `AGING_ASSIGNED`,
       case
           when (select count(0)
                 from `emdev`.`TBL_ASSIGNMENT_LOG` `H`
                 where `H`.`C_ID` = `A`.`C_ID` and `H`.`AL_TYPE` = 'SELF'
                 limit 1) > 0 then (select min(`H`.`LOGGED_DATE`)
                                    from `emdev`.`TBL_ASSIGNMENT_LOG` `H`
                                    where `H`.`C_ID` = `A`.`C_ID`
                                      and `H`.`AL_TYPE` = 'SELF'
                                    limit 1)
           else (select min(`H`.`LOGGED_DATE`)
                 from `emdev`.`TBL_ASSIGNMENT_LOG` `H`
                 where `H`.`C_ID` = `A`.`C_ID`
                   and `H`.`AL_TYPE` = 'SUPPORT'
                 limit 1) end                                                                                         AS `ASSIGNED_DATE`,
       case
           when (select count(0)
                 from `emdev`.`TBL_ASSIGNMENT_LOG` `H`
                 where `H`.`C_ID` = `A`.`C_ID`
                   and `H`.`AL_TYPE` = 'SUPPORT'
                 limit 1) > 0 then to_days((select `G`.`LOGGED_DATE`
                                            from `emdev`.`TBL_ACTION_REMARK` `G`
                                            where `G`.`C_ID` = `A`.`C_ID`
                                              and `G`.`REMARK_TYPE` = 'IN-PROGRESS'
                                            limit 1)) - to_days((select min(`H`.`LOGGED_DATE`)
                                                                 from `emdev`.`TBL_ASSIGNMENT_LOG` `H`
                                                                 where `H`.`C_ID` = `A`.`C_ID`
                                                                   and `H`.`H_ID_SUPPORT` <> 0
                                                                 limit 1))
           else to_days((select `G`.`LOGGED_DATE`
                         from `emdev`.`TBL_ACTION_REMARK` `G`
                         where `G`.`C_ID` = `A`.`C_ID`
                           and `G`.`REMARK_TYPE` = 'IN-PROGRESS'
                         limit 1)) - to_days((select min(`H`.`LOGGED_DATE`)
                                              from `emdev`.`TBL_ASSIGNMENT_LOG` `H`
                                              where `H`.`C_ID` = `A`.`C_ID`
                                              limit 1)) end                                                           AS `AGING_INPROGRESS`,
       (select `G`.`LOGGED_DATE`
        from `emdev`.`TBL_ACTION_REMARK` `G`
        where `G`.`C_ID` = `A`.`C_ID`
          and `G`.`REMARK_TYPE` = 'IN-PROGRESS'
        limit 1)                                                                                                      AS `INPROGRESS_DATE`,
       to_days((select `G`.`LOGGED_DATE`
                from `emdev`.`TBL_ACTION_REMARK` `G`
                where `G`.`C_ID` = `A`.`C_ID`
                  and `G`.`REMARK_TYPE` = 'CANCELLED'
                limit 1)) -
       to_days(`A`.`CREATED_DATE`)                                                                                    AS `AGING_CANCELLED`,
       (select `G`.`LOGGED_DATE`
        from `emdev`.`TBL_ACTION_REMARK` `G`
        where `G`.`C_ID` = `A`.`C_ID`
          and `G`.`REMARK_TYPE` = 'CANCELLED'
        limit 1)                                                                                                      AS `CANCELLED_DATE`,
       case
           when `B`.`CASE_STATUS` = 70 then to_days(`A`.`CLOSED_DATE`) - to_days(`A`.`CREATED_DATE`)
           when `B`.`CASE_STATUS` = 73 then to_days((select `G`.`LOGGED_DATE`
                                                     from `emdev`.`TBL_ACTION_REMARK` `G`
                                                     where `G`.`C_ID` = `A`.`C_ID`
                                                       and `G`.`REMARK_TYPE` = 'CANCELLED'
                                                     limit 1)) - to_days(`A`.`CREATED_DATE`)
           else to_days(current_timestamp()) - to_days(`A`.`CREATED_DATE`) end                                        AS `AGING`,
       `B`.`RATING`                                                                                                   AS `RATING`,
       ifnull(`B`.`FLAG`, 'COMPLAINT')                                                                                AS `FLAG`,
       `B`.`CKC`                                                                                                      AS `CKC`,
       `B`.`CKC_NUM`                                                                                                  AS `CKC_NUM`,
       `B`.`EXT_SYS_REF`                                                                                              AS `EXT_SYS_REF`,
       `B`.`STAKEHOLDER_REF`                                                                                          AS `STAKEHOLDER_REF`
from (`emdev`.`TBL_CASE` `A`
         join `emdev`.`TBL_CASE_DETAIL` `B` on (`A`.`C_ID` = `B`.`C_ID`))
where case
          when (select `C`.`L_NAME` from `emdev`.`TBL_LOV` `C` where `C`.`L_ID` = `B`.`CASE_STATUS`) = 'NEW'
              then 'UNASSIGNED'
          else (select `C`.`L_NAME` from `emdev`.`TBL_LOV` `C` where `C`.`L_ID` = `B`.`CASE_STATUS`) end <>
      'TO-BE-DELETED'
  and `A`.`CREATED_DATE` between current_timestamp() - interval 90 day and current_timestamp();

-- comment on column VW_HERO_REPORTING.HERO_CASE_ID not supported: 12D = H-1710170012

-- comment on column VW_HERO_REPORTING.RATING not supported: FROM 1 - 10

-- comment on column VW_HERO_REPORTING.STAKEHOLDER_REF not supported: RRT,NMO,CSM,NOC

