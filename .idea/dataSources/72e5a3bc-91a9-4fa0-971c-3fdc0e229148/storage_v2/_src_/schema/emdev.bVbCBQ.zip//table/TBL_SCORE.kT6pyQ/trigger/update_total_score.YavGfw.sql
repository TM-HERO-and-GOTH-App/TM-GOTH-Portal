create definer = root@`%` trigger update_total_score
    after insert
    on TBL_SCORE
    for each row
BEGIN
	CALL Update_Total_Score(NEW.H_ID);
END;

