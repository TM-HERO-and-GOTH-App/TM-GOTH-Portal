create view VW_ACTION_REMARK as
select `T1`.`C_ID`        AS `C_ID`,
       `T1`.`CT_ID`       AS `CT_ID`,
       `T1`.`REMARK_TYPE` AS `REMARK_TYPE`,
       `T1`.`REMARK`      AS `REMARK`,
       `T1`.`LOGGED_DATE` AS `LOGGED_DATE`,
       `T2`.`CASE_NUM`    AS `CASE_NUM`,
       `T3`.`H_ID`        AS `H_ID`,
       `T3`.`FULLNAME`    AS `UPDATED_BY`,
       `T4`.`L_NAME`      AS `CLOSURE_TYPE`,
       `T5`.`PICTURE`     AS `FILENAME`
from ((((`emdev`.`TBL_ACTION_REMARK` `T1` join `emdev`.`TBL_CASE` `T2` on (`T2`.`C_ID` = `T1`.`C_ID`)) join `emdev`.`TBL_HERO` `T3` on (`T3`.`H_ID` = `T1`.`H_ID`)) left join `emdev`.`TBL_LOV` `T4` on (`T4`.`L_ID` = `T1`.`CT_ID`))
         left join `emdev`.`TBL_BLOB` `T5` on (`T5`.`B_ID` = `T1`.`B_ID`));

-- comment on column VW_ACTION_REMARK.CT_ID not supported: CLOSURE_TYPE; REFER TO L_ID FROM TBL_LOV

-- comment on column VW_ACTION_REMARK.REMARK_TYPE not supported: NEW/ASSIGNED/IN-PROGRESS/CLOSED

-- comment on column VW_ACTION_REMARK.CASE_NUM not supported: 12D = H-1710170012

-- comment on column VW_ACTION_REMARK.H_ID not supported: HERO_ID FOR SYS USED

