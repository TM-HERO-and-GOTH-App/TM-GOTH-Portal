create definer = root@`%` trigger update_total_score_if_cancelled
    after delete
    on TBL_SCORE
    for each row
BEGIN
	CALL Update_Total_Score(OLD.H_ID);
END;

