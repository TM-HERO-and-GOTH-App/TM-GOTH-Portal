create definer = root@localhost trigger update_total_score
    after insert
    on tbl_score
    for each row
begin
    -- missing source code
end;

