create definer = root@localhost trigger backup_tbl_case
    before delete
    on tbl_case
    for each row
begin
    -- missing source code
end;

