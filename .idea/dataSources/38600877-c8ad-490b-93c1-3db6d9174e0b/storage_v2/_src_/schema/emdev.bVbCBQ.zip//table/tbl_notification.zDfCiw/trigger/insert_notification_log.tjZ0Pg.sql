create definer = root@localhost trigger insert_notification_log
    after insert
    on tbl_notification
    for each row
begin
    -- missing source code
end;

