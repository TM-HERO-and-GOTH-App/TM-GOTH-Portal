create definer = root@localhost trigger create_new_user
    before insert
    on tbl_hero
    for each row
begin
    -- missing source code
end;

