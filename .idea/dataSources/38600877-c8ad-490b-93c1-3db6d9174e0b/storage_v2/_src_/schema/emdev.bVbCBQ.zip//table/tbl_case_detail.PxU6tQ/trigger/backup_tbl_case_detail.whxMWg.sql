create definer = root@localhost trigger backup_tbl_case_detail
    before delete
    on tbl_case_detail
    for each row
begin
    -- missing source code
end;

