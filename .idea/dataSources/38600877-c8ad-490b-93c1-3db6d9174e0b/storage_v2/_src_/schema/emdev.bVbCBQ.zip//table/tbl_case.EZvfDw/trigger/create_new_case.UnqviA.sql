create definer = root@localhost trigger create_new_case
    before insert
    on tbl_case
    for each row
begin
    -- missing source code
end;

