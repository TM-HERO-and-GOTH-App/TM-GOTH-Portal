create definer = root@localhost trigger update_total_score_if_cancelled
    after delete
    on tbl_score
    for each row
begin
    -- missing source code
end;

